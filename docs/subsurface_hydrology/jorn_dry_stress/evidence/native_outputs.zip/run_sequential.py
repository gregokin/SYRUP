from pathlib import Path
import json,subprocess,hashlib,datetime
P=Path(__file__).resolve().parent;idx=json.loads((P/'config_paths.json').read_text());manifest={}
for key,v in idx['cases'].items():
 for name in ('path','runner_config','probe'):
  f=Path(v[name]);manifest[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
(P/'run_input_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');done=[]
for key,v in idx['cases'].items():
 print('RUN',key,flush=True);subprocess.run(['/home/okin/MAPLE/.venv/bin/python',str(P/'root_release_verified_launcher.py'),v['runner_config']],check=True);done.append(key)
 assert all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in manifest.items())
 (P/'run_progress.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed':done,'total':6,'status':'complete' if len(done)==6 else 'running','all_inputs_unchanged':True},indent=2)+'\n')
print('ALL6_NATIVE_DRY_CASES_COMPLETE',flush=True)
