from pathlib import Path
import json,hashlib
from benchmarks.subsurface_wet_validation import driver
P=Path(__file__).resolve().parent
A=Path('/home/okin/SYRUP/agent_handoffs/tasks/jorn_evap_sensitivity_20261120/analysis_candidate')
m=json.loads((P/'frozen_helper_manifest.json').read_text())
def check():
 for f,h in m.items():assert hashlib.sha256((A/f).read_bytes()).hexdigest()==h
check()
args=['--config',str(P/'case_numba.json'),'--out',str(P/'actual_numba_resumed'),'--execute']+['--resume-state', '/home/okin/SYRUP/agent_handoffs/tasks/jorn_evap_sensitivity_20261120/study/s3/driver_state_day80.json']
assert driver.main(args)==0
check()
