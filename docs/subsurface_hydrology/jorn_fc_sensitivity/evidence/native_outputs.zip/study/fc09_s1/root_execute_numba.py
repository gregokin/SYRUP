from pathlib import Path
import json,hashlib,time,sys,platform,resource
P=Path(__file__).resolve().parent
A=Path('/home/okin/SYRUP/agent_handoffs/tasks/jorn_fc_sensitivity_20261120/analysis_candidate')
manifest=json.loads((P/'frozen_helper_manifest.json').read_text())
def check():
 for rel,want in manifest.items():assert hashlib.sha256((A/rel).read_bytes()).hexdigest()==want,rel
check()
t=time.perf_counter()
from benchmarks.subsurface_wet_validation import driver
CASE='numba'
output=P/('actual_'+CASE)
rc=driver.main(['--config',str(P/('case_'+CASE+'.json')),'--out',str(output),'--execute'])
assert rc==0
check()
record={'driver_call_wall_s':time.perf_counter()-t,'scope':'includes driver import/case validation/preparation/disposable kernel warmup/integration/output; excludes outer interpreter/bootstrap/source checks','python':sys.version,'platform':platform.platform(),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'model_scope':'one 1 m2 three-layer column, not domain-scaling/GPU benchmark','source_helper_unchanged':True}
(P/('runtime_'+CASE+'.json')).write_text(json.dumps(record,indent=2)+chr(10))
