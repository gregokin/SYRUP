from pathlib import Path
import subprocess,json,datetime,hashlib
P=Path(__file__).resolve().parent
paths={k:v['variants'] for k,v in json.loads((P/'config_paths.json').read_text())['cases'].items()}
KEYS=tuple(f'fc{fc:02d}_s{label}' for label in ('1','1p5') for fc in range(9,16))
manifest={}
for key in KEYS:
 for variant in ('numba','numpy','numba_dt900'):
  info=paths[key][variant]
  for name in ('path','runner_config','probe'):
   f=Path(info[name]);assert f.is_absolute() and f.is_file(),f
   manifest[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
  cfg=json.loads(Path(info['runner_config']).read_text());assert (Path(info['runner_config']).parent/'root_release_verified_bootstrap.py').is_file()
(P/'run_input_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
completed=[]
for variant in ('numba','numpy','numba_dt900'):
 for key in KEYS:
  print('RUN',key,variant,flush=True)
  subprocess.run(['/home/okin/MAPLE/.venv/bin/python',str(P/'root_release_verified_launcher.py'),paths[key][variant]['runner_config']],check=True)
  completed.append(key+'/'+variant)
  assert all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in manifest.items())
  (P/'run_progress.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed':completed,'total':42,'status':'running' if len(completed)<42 else 'complete','input_manifest_unchanged':True},indent=2)+'\n')
print('ALL42NATIVE160DAYRUNS_COMPLETED',flush=True)
